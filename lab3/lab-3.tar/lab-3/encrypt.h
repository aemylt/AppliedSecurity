#ifndef __ENCRYPT_H
#define __ENCRYPT_H

#include  <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <openssl/aes.h> 

#endif
